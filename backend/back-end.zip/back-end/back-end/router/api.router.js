const express = require('express');
const isAuthenticated = require('../middleware/auth');
const {  changeEmail, changPassword} = require('../controller/api.controller');
const { generatePassword } = require('../controller/auth.controller');
const apiRouter = express.Router();

apiRouter.post("/change-email", isAuthenticated, changeEmail);
apiRouter.post("/change-password", isAuthenticated, changPassword);
apiRouter.get("/generate-password", generatePassword);

module.exports = apiRouter;