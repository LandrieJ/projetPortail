const express = require('express');
const materielRouter = express.Router();
const { getMateriels, getMateriel, updateMateriel, addMateriel, deleteMateriel } = require('../controller/materiel.controller');
const upload = require('../middleware/uploads');
const isAuthenticated = require('../middleware/auth');

// Routes
materielRouter.get("/", isAuthenticated, getMateriels);
materielRouter.get("/:id?", isAuthenticated, getMateriel);
materielRouter.put("/", isAuthenticated, upload.single('image'), addMateriel);
materielRouter.put("/:id", isAuthenticated, upload.single('image'), updateMateriel);
materielRouter.delete("/:id?", isAuthenticated, deleteMateriel);

module.exports = materielRouter;
