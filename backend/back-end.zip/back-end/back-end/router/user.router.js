const express = require('express');
const userRouter = express.Router();
const { getUsers, getUser, updateUser, addUser, deleteUser } = require('../controller/user.controller');
const isAdmin = require('../middleware/admin');

userRouter.get("/", isAdmin, getUsers);
userRouter.get("/:id?", isAdmin, getUser);
userRouter.post("/", isAdmin, addUser);
userRouter.put("/:id?", isAdmin, updateUser);
userRouter.delete("/:id?", isAdmin, deleteUser);

module.exports = userRouter;